from Gestion.systeme_tickets import ROLES

from .controleur_tickets import TicketController


class AppController:
    def __init__(self, system):
        self.system = system

    def subscribe(self, observer):
        self.system.attach(observer)

    def unsubscribe(self, observer):
        self.system.detach(observer)

    def accounts(self):
        return self.system.people()

    def roles(self):
        return list(ROLES)

    def create_account(self, name, email, role):
        return self.system.create_account(name, email, role)

    def open_session(self, person_id):
        person = self.system.find_person(person_id)
        return TicketController(self.system, person)
