from Gestion import BusinessError, ContentError, ValidationError
from Modele import Action, Priority, TextContent, TicketStatus, create_content

HISTORY_LIMIT = 20


class TicketController:
    def __init__(self, system, actor):
        self.system = system
        self.actor = actor
        self.is_admin = actor.is_admin
        self.history = []

    def subscribe(self, observer):
        self.system.attach(observer)

    def unsubscribe(self, observer):
        self.system.detach(observer)

    def can(self, action, ticket=None):
        if not self.actor.can(action, ticket):
            return False
        if ticket is None:
            return True
        return ticket.allows(action)

    def ticket(self, ticket_id):
        return self.actor.view_ticket(ticket_id)

    def tickets(self):
        if self.is_admin:
            return self.actor.view_all_tickets()
        return self.system.tickets_for(self.actor)

    def assignable_users(self):
        result = []
        for user in self.system.users():
            result.append((user, self.system.active_count(user)))
        return result

    def allowed_statuses(self, ticket_id):
        return self.ticket(ticket_id).allowed_statuses()

    def read_text_file(self, path):
        return TextContent.from_file(path).text

    def priority_labels(self):
        return [priority.label for priority in Priority]

    def status_labels(self):
        return [status.label for status in TicketStatus]

    def create_ticket(self, title, priority_label, blocks):
        if not self.can(Action.CREATE):
            raise BusinessError("Seul un utilisateur peut créer un ticket.")
        priority, contents = self.read_form(priority_label, blocks)
        return self.actor.create_ticket(title, priority, contents)

    def update_ticket(self, ticket_id, title, priority_label, blocks):
        priority, contents = self.read_form(priority_label, blocks)
        before = self.ticket(ticket_id).create_memento()
        self.actor.update_ticket(ticket_id, title, priority, contents)
        self.remember(f"Modification du ticket #{ticket_id}", ticket_id, before)
        return self.ticket(ticket_id)

    def add_comment(self, ticket_id, text):
        before = self.ticket(ticket_id).create_memento()
        self.system.add_comment(self.actor, ticket_id, text)
        self.remember(f"Commentaire sur #{ticket_id}", ticket_id, before)

    def assign(self, ticket_id, user_id):
        user = self.system.find_person(user_id)
        before = self.ticket(ticket_id).create_memento()
        self.actor.assign_ticket(ticket_id, user_id)
        self.remember(f"Assignation de #{ticket_id} à {user.name}", ticket_id, before)
        return f"Ticket #{ticket_id} assigné à {user.name}."

    def change_status(self, ticket_id, status_label):
        status = TicketStatus.from_label(status_label)
        if status not in self.allowed_statuses(ticket_id):
            raise BusinessError(f"Le statut « {status.label} » n'est pas permis pour #{ticket_id}.")
        before = self.ticket(ticket_id).create_memento()
        self.system.change_status(self.actor, ticket_id, status)
        self.remember(f"Statut « {status.label} » pour #{ticket_id}", ticket_id, before)
        return f"Ticket #{ticket_id} : statut « {status.label} »."

    def submit_for_validation(self, ticket_id):
        before = self.ticket(ticket_id).create_memento()
        self.system.submit_for_validation(self.actor, ticket_id)
        self.remember(f"Soumission de #{ticket_id}", ticket_id, before)
        return f"Ticket #{ticket_id} soumis pour validation."

    def validate(self, ticket_id):
        before = self.ticket(ticket_id).create_memento()
        self.system.validate(self.actor, ticket_id)
        self.remember(f"Validation de #{ticket_id}", ticket_id, before)
        return f"Ticket #{ticket_id} validé et terminé."

    def reject(self, ticket_id, reason):
        before = self.ticket(ticket_id).create_memento()
        self.system.reject(self.actor, ticket_id, reason)
        self.remember(f"Refus de #{ticket_id}", ticket_id, before)
        return f"Résolution du ticket #{ticket_id} refusée : retour au responsable."

    def close(self, ticket_id, reason):
        before = self.ticket(ticket_id).create_memento()
        self.actor.close_ticket(ticket_id, reason)
        self.remember(f"Fermeture de #{ticket_id}", ticket_id, before)
        return f"Ticket #{ticket_id} fermé."

    def reopen(self, ticket_id):
        before = self.ticket(ticket_id).create_memento()
        self.system.reopen(self.actor, ticket_id)
        self.remember(f"Réouverture de #{ticket_id}", ticket_id, before)
        return f"Ticket #{ticket_id} rouvert."

    def remember(self, label, ticket_id, memento):
        self.history.append((label, ticket_id, memento))
        if len(self.history) > HISTORY_LIMIT:
            self.history.pop(0)

    def can_undo(self):
        return len(self.history) > 0

    def undo_label(self):
        if not self.history:
            return ""
        label, ticket_id, memento = self.history[-1]
        return label

    def undo(self):
        if not self.history:
            raise BusinessError("Aucune action à annuler.")
        label, ticket_id, memento = self.history.pop()
        self.system.restore(self.actor, ticket_id, memento)
        return f"Action annulée : {label}."

    def read_form(self, priority_label, blocks):
        errors = {}
        priority = None
        try:
            priority = Priority.from_label(priority_label)
        except ValueError:
            errors["priority"] = "Choisissez une priorité."
        contents = []
        position = 1
        for block in blocks:
            try:
                contents.append(create_content(block))
            except ContentError as error:
                if "description" not in errors:
                    errors["description"] = f"Bloc {position} : {error}"
            position += 1
        if not contents and "description" not in errors:
            errors["description"] = "La description doit contenir au moins un texte ou une image."
        if errors:
            raise ValidationError(errors)
        return priority, contents
