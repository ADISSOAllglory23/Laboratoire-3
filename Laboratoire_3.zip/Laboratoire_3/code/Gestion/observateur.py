from abc import ABC, abstractmethod
from enum import Enum


class EventType(Enum):
    ACCOUNT_CREATED = "Compte créé"
    TICKET_CREATED = "Ticket créé"
    TICKET_UPDATED = "Ticket modifié"
    COMMENT_ADDED = "Commentaire ajouté"
    TICKET_ASSIGNED = "Ticket assigné"
    STATUS_CHANGED = "Statut modifié"
    TICKET_RESTORED = "Action annulée"


class BusinessEvent:
    def __init__(self, type, actor=None, ticket_id=None, message=""):
        self.type = type
        self.actor = actor
        self.ticket_id = ticket_id
        self.message = message


class Observer(ABC):
    @abstractmethod
    def on_event(self, event):
        pass


class Subject:
    def __init__(self):
        self._observers = []

    def attach(self, observer):
        if observer not in self._observers:
            self._observers.append(observer)

    def detach(self, observer):
        if observer in self._observers:
            self._observers.remove(observer)

    def notify(self, event):
        for observer in list(self._observers):
            observer.on_event(event)


class BusinessError(Exception):
    pass


class NotFound(BusinessError):
    pass


class PermissionDenied(BusinessError):
    pass


class InvalidTransition(BusinessError):
    pass


class ContentError(BusinessError):
    pass


class ValidationError(BusinessError):
    def __init__(self, errors):
        self.errors = errors
        super().__init__(" ; ".join(errors.values()))
