from tkinter import ttk

POLICE = "Segoe UI"

FOND = "#f3f4f6"
BLANC = "#ffffff"
BORDURE = "#d1d5db"
TEXTE = "#111827"
GRIS = "#4b5563"
FONCE = "#1f2937"
BLEU = "#1d4ed8"
BLEU_FONCE = "#1e3a8a"
ROUGE = "#b91c1c"
VERT = "#166534"

COULEURS_STATUTS = {
    "OUVERT": "#dbeafe",
    "ASSIGNE": "#fef3c7",
    "VALIDATION": "#f3e8ff",
    "TERMINE": "#dcfce7",
}

COULEURS_PRIORITES = {
    "BASSE": "#6b7280",
    "NORMALE": "#111827",
    "HAUTE": "#d97706",
    "CRITIQUE": "#b91c1c",
}


def appliquer_style(root):
    root.configure(bg=FOND)
    root.option_add("*Toplevel.background", FOND)
    root.option_add("*Frame.background", FOND)
    root.option_add("*Label.background", FOND)
    root.option_add("*Label.font", (POLICE, 10))
    root.option_add("*Canvas.background", FOND)
    root.option_add("*Text.background", BLANC)
    root.option_add("*Text.font", (POLICE, 10))

    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure(".", background=FOND, foreground=TEXTE, font=(POLICE, 10))

    style.configure("Titre.TLabel", font=(POLICE, 14, "bold"))
    style.configure("Gras.TLabel", font=(POLICE, 10, "bold"))
    style.configure("Gris.TLabel", foreground=GRIS)
    style.configure("Erreur.TLabel", foreground=ROUGE, font=(POLICE, 10, "bold"))
    style.configure("Succes.TLabel", foreground=VERT)

    style.configure("Entete.TFrame", background=FONCE)
    style.configure("Entete.TLabel", background=FONCE, foreground=BLANC, font=(POLICE, 14, "bold"))
    style.configure("EnteteGris.TLabel", background=FONCE, foreground=BORDURE)

    for nom, couleur in COULEURS_STATUTS.items():
        style.configure(nom + ".TLabel", background=couleur, padding=(8, 2), font=(POLICE, 10, "bold"))
    for nom, couleur in COULEURS_PRIORITES.items():
        style.configure(nom + ".TLabel", foreground=couleur, font=(POLICE, 10, "bold"))

    style.configure("TButton", padding=(10, 5))
    style.configure("Accent.TButton", background=BLEU, foreground=BLANC, font=(POLICE, 10, "bold"))
    style.map("Accent.TButton", background=[("active", BLEU_FONCE), ("disabled", BORDURE)])
    style.configure("Danger.TButton", foreground=ROUGE)
    style.map("Danger.TButton", foreground=[("disabled", BORDURE)])

    style.configure("TEntry", padding=4)
    style.configure("Treeview", rowheight=26, background=BLANC, fieldbackground=BLANC)
    style.configure("Treeview.Heading", font=(POLICE, 10, "bold"))
    style.map("Treeview", background=[("selected", BLEU)], foreground=[("selected", BLANC)])
