from .observateur import (BusinessEvent, EventType, InvalidTransition, NotFound, PermissionDenied,
                         Subject, ValidationError)
from Modele.Admin import Admin
from Modele.Ticket import Ticket, TicketStatus
from Modele.User import Action, User

ROLES = {User.role: User, Admin.role: Admin}


class TicketSystem(Subject):
    def __init__(self):
        super().__init__()
        self._tickets = {}
        self._people = {}
        self._next_ticket_id = 1
        self._next_person_id = 1

    def create_account(self, name, email, role):
        if role not in ROLES:
            raise ValidationError({"role": f"Rôle inconnu : {role}"})
        email = (email or "").strip().lower()
        for person in self._people.values():
            if person.email == email:
                raise ValidationError({"email": "Un compte utilise déjà ce courriel."})
        person_class = ROLES[role]
        person = person_class(self._next_person_id, name, email, self)
        self._people[person.person_id] = person
        self._next_person_id += 1
        self.notify(BusinessEvent(EventType.ACCOUNT_CREATED, person, None,
                                  f"Compte créé : {person.name} ({person.role})"))
        return person

    def people(self):
        users = [p for p in self._people.values() if not p.is_admin]
        admins = [p for p in self._people.values() if p.is_admin]
        return users + admins

    def users(self):
        return [p for p in self._people.values() if isinstance(p, User)]

    def find_person(self, person_id):
        if person_id not in self._people:
            raise NotFound(f"Compte #{person_id} introuvable.")
        return self._people[person_id]

    def active_count(self, person):
        count = 0
        for ticket in self._tickets.values():
            if ticket.assigned_to is person and ticket.status is not TicketStatus.TERMINE:
                count += 1
        return count

    def tickets_for(self, actor):
        if actor.can(Action.VIEW_ALL):
            return list(self._tickets.values())
        return [t for t in self._tickets.values() if actor.can(Action.VIEW, t)]

    def get_ticket(self, actor, ticket_id):
        ticket = self._tickets.get(ticket_id)
        if ticket is None:
            raise NotFound(f"Ticket #{ticket_id} introuvable.")
        if not actor.can(Action.VIEW, ticket):
            raise PermissionDenied(f"Vous n'avez pas accès au ticket #{ticket_id}.")
        return ticket

    def _ticket_for(self, actor, ticket_id, action):
        ticket = self.get_ticket(actor, ticket_id)
        self._require(actor, action, ticket)
        return ticket

    def _require(self, actor, action, ticket=None):
        if not actor.can(action, ticket):
            raise PermissionDenied(f"Action « {action.label} » non permise "
                                   f"pour le rôle {actor.role.lower()}.")
        if ticket is not None and not ticket.allows(action):
            raise InvalidTransition(f"Action « {action.label} » impossible : le ticket "
                                    f"#{ticket.ticket_id} est « {ticket.status.label} ».")

    def _emit(self, event_type, actor, ticket, message):
        self.notify(BusinessEvent(event_type, actor, ticket.ticket_id, message))

    def create_ticket(self, actor, title, priority, contents):
        self._require(actor, Action.CREATE)
        ticket = Ticket(self._next_ticket_id, title, priority, actor, contents)
        self._tickets[ticket.ticket_id] = ticket
        self._next_ticket_id += 1
        self._emit(EventType.TICKET_CREATED, actor, ticket,
                   f"{actor.name} a créé le ticket #{ticket.ticket_id}.")
        return ticket

    def update_ticket(self, actor, ticket_id, title, priority, contents):
        ticket = self._ticket_for(actor, ticket_id, Action.EDIT)
        ticket.update_details(title, priority, contents)
        self._emit(EventType.TICKET_UPDATED, actor, ticket,
                   f"{actor.name} a modifié le ticket #{ticket_id}.")
        return ticket

    def add_comment(self, actor, ticket_id, text):
        ticket = self._ticket_for(actor, ticket_id, Action.COMMENT)
        comment = ticket.add_comment(actor, text)
        self._emit(EventType.COMMENT_ADDED, actor, ticket,
                   f"{actor.name} a commenté le ticket #{ticket_id}.")
        return comment

    def assign(self, actor, ticket_id, assignee_id):
        ticket = self._ticket_for(actor, ticket_id, Action.ASSIGN)
        assignee = self.find_person(assignee_id)
        if not isinstance(assignee, User):
            raise ValidationError({"assignee": "Un ticket ne peut être assigné qu'à un utilisateur."})
        ticket.assign_to(assignee)
        self._emit(EventType.TICKET_ASSIGNED, actor, ticket,
                   f"{actor.name} a assigné le ticket #{ticket_id} à {assignee.name}.")
        return ticket

    def submit_for_validation(self, actor, ticket_id):
        return self._transition(actor, ticket_id, Action.SUBMIT, TicketStatus.VALIDATION)

    def validate(self, actor, ticket_id):
        return self._transition(actor, ticket_id, Action.VALIDATE, TicketStatus.TERMINE)

    def reject(self, actor, ticket_id, reason):
        return self._transition(actor, ticket_id, Action.REJECT, TicketStatus.ASSIGNE,
                                reason, "Résolution refusée")

    def close(self, actor, ticket_id, reason):
        return self._transition(actor, ticket_id, Action.CLOSE, TicketStatus.TERMINE,
                                reason, "Ticket fermé")

    def reopen(self, actor, ticket_id):
        return self._transition(actor, ticket_id, Action.REOPEN, TicketStatus.OUVERT)

    def change_status(self, actor, ticket_id, status):
        return self._transition(actor, ticket_id, Action.CHANGE_STATUS, status)

    def _transition(self, actor, ticket_id, action, status, reason=None, prefix=""):
        ticket = self._ticket_for(actor, ticket_id, action)
        if reason is not None and not reason.strip():
            raise ValidationError({"reason": "Indiquez la raison (elle sera ajoutée en commentaire)."})
        old = ticket.status
        ticket.update_status(status)
        if reason:
            ticket.add_comment(actor, f"[{prefix}] {reason.strip()}")
        self._emit(EventType.STATUS_CHANGED, actor, ticket,
                   f"{actor.name} : ticket #{ticket_id} « {old.label} » → « {status.label} ».")
        return ticket

    def restore(self, actor, ticket_id, memento):
        ticket = self.get_ticket(actor, ticket_id)
        ticket.restore(memento)
        self._emit(EventType.TICKET_RESTORED, actor, ticket,
                   f"{actor.name} a annulé sa dernière action sur le ticket #{ticket_id}.")
        return ticket
