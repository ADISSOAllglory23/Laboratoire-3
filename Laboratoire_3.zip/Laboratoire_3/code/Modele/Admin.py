from .User import Action, Person


class Admin(Person):
    role = "Administrateur"
    _NOT_ALLOWED = {Action.CREATE, Action.SUBMIT}

    @property
    def is_admin(self) -> bool:
        return True

    def assign_ticket(self, ticket_id: int, user_id: int):
        return self.system.assign(self, ticket_id, user_id)

    def close_ticket(self, ticket_id: int, reason: str):
        return self.system.close(self, ticket_id, reason)

    def view_all_tickets(self) -> list:
        return self.system.tickets_for(self)

    def can(self, action: Action, ticket=None) -> bool:
        if action in self._NOT_ALLOWED:
            return False
        if action is Action.VIEW_ALL:
            return True
        return ticket is not None
