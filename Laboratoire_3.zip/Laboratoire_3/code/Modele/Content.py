import os
from abc import ABC, abstractmethod

from Gestion.observateur import ContentError

IMAGE_EXTENSIONS = (".png", ".gif", ".jpg", ".jpeg", ".bmp")


class TicketContent(ABC):
    kind = "abstrait"
    type_label = "Contenu"

    @abstractmethod
    def load(self):
        pass

    @abstractmethod
    def export_to_pdf(self) -> str:
        pass

    @abstractmethod
    def to_dict(self) -> dict:
        pass


class TextContent(TicketContent):
    kind = "texte"
    type_label = "Texte"

    def __init__(self, text: str):
        self.text = str(text or "").strip("\n")

    @classmethod
    def from_file(cls, path: str) -> "TextContent":
        if not os.path.exists(path):
            raise ContentError(f"Fichier texte introuvable : {path}")
        try:
            with open(path, "r", encoding="utf-8") as fichier:
                contenu = fichier.read()
        except UnicodeDecodeError:
            raise ContentError(
                f"{os.path.basename(path)} n'est pas lisible comme du texte UTF-8 "
                f"(mauvais encodage, ou ce n'est pas vraiment un fichier texte)."
            ) from None
        except OSError as erreur:
            raise ContentError(f"Erreur de lecture de {path} : {erreur}") from None
        return cls(contenu)

    def load(self) -> str:
        return self.text

    def export_to_pdf(self) -> str:
        return "[Texte] Le texte est inséré tel quel dans le PDF."

    def to_dict(self) -> dict:
        return {"kind": self.kind, "text": self.text}


class ImageContent(TicketContent):
    kind = "image"
    type_label = "Image"

    def __init__(self, path: str):
        if not path:
            raise ContentError("Aucun fichier image n'a été choisi.")
        extension = os.path.splitext(path)[1].lower()
        if extension not in IMAGE_EXTENSIONS:
            raise ContentError(
                f"Format d'image non pris en charge ({extension or 'sans extension'}). "
                f"Formats acceptés : {', '.join(IMAGE_EXTENSIONS)}."
            )
        if not os.path.exists(path):
            raise ContentError(f"Image introuvable : {path}")
        self.path = os.path.abspath(path)

    @property
    def file_name(self) -> str:
        return os.path.basename(self.path)

    def load(self) -> str:
        if not os.path.exists(self.path):
            raise ContentError(f"Image introuvable : {self.path}")
        return self.path

    def export_to_pdf(self) -> str:
        return f"[Image] L'image {self.path} est incrustée directement dans le PDF."

    def to_dict(self) -> dict:
        return {"kind": self.kind, "path": self.path}


class VideoContent(TicketContent):
    kind = "video"
    type_label = "Vidéo"

    def __init__(self, path: str):
        if not path:
            raise ContentError("Aucun fichier vidéo n'a été choisi.")
        self.path = path

    def load(self) -> str:
        if not os.path.exists(self.path):
            raise ContentError(f"Vidéo introuvable : {self.path}")
        return self.path

    def export_to_pdf(self) -> str:
        return (f"[Vidéo] Une vidéo ne peut pas être intégrée dans un PDF statique. "
                f"Insertion d'un lien vers {self.path} à la place.")

    def to_dict(self) -> dict:
        return {"kind": self.kind, "path": self.path}


_REGISTRY = {cls.kind: cls for cls in (TextContent, ImageContent, VideoContent)}


def create_content(data: dict) -> TicketContent:
    kind = data.get("kind")
    content_class = _REGISTRY.get(kind)
    if content_class is None:
        raise ContentError(f"Type de contenu inconnu : {kind}")
    params = {key: value for key, value in data.items() if key != "kind"}
    return content_class(**params)
