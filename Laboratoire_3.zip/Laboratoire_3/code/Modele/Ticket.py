from datetime import datetime
from enum import Enum

from Gestion.observateur import ContentError, InvalidTransition
from .User import Action


class TicketStatus(Enum):
    OUVERT = "Ouvert"
    ASSIGNE = "Assigné"
    VALIDATION = "En validation"
    TERMINE = "Terminé"

    @property
    def label(self):
        return self.value

    def can_go_to(self, other):
        return other in TRANSITIONS[self]

    @classmethod
    def from_label(cls, label):
        for status in cls:
            if status.label == label:
                return status
        raise ValueError(f"Statut inconnu : {label}")


TRANSITIONS = {
    TicketStatus.OUVERT: [TicketStatus.ASSIGNE, TicketStatus.TERMINE],
    TicketStatus.ASSIGNE: [TicketStatus.OUVERT, TicketStatus.VALIDATION, TicketStatus.TERMINE],
    TicketStatus.VALIDATION: [TicketStatus.ASSIGNE, TicketStatus.TERMINE],
    TicketStatus.TERMINE: [TicketStatus.OUVERT],
}


class Priority(Enum):
    BASSE = "Basse"
    NORMALE = "Normale"
    HAUTE = "Haute"
    CRITIQUE = "Critique"

    @property
    def label(self):
        return self.value

    @classmethod
    def from_label(cls, label):
        for priority in cls:
            if priority.label == label:
                return priority
        raise ValueError(f"Priorité inconnue : {label}")


class Comment:
    def __init__(self, author, text, date):
        self.author = author
        self.text = text
        self.date = date


class TicketMemento:
    def __init__(self, ticket):
        self.title = ticket.title
        self.priority = ticket.priority
        self.status = ticket.status
        self.assigned_to = ticket.assigned_to
        self.contents = list(ticket.contents)
        self.comments = list(ticket.comments)


class Ticket:
    def __init__(self, ticket_id, title, priority, author, contents):
        self.ticket_id = ticket_id
        self.title = (title or "").strip()
        self.priority = priority
        self.status = TicketStatus.OUVERT
        self.author = author

        self.creation_date = datetime.now()
        self.update_date = self.creation_date

        self.assigned_to = None
        self.comments = []
        self.contents = []
        self.set_contents(contents)

    def allows(self, action):
        status = self.status
        if action in (Action.VIEW, Action.COMMENT, Action.VIEW_ALL):
            return True
        if action is Action.EDIT:
            return status in (TicketStatus.OUVERT, TicketStatus.ASSIGNE)
        if action is Action.ASSIGN:
            return status in (TicketStatus.OUVERT, TicketStatus.ASSIGNE)
        if action is Action.SUBMIT:
            return status is TicketStatus.ASSIGNE
        if action in (Action.VALIDATE, Action.REJECT):
            return status is TicketStatus.VALIDATION
        if action is Action.CLOSE:
            return status is not TicketStatus.TERMINE
        if action is Action.REOPEN:
            return status is TicketStatus.TERMINE
        if action is Action.CHANGE_STATUS:
            return len(self.allowed_statuses()) > 0
        return False

    def can_change_to(self, status):
        if not self.status.can_go_to(status):
            return False
        if status is TicketStatus.ASSIGNE and self.assigned_to is None:
            return False
        return True

    def allowed_statuses(self):
        allowed = set()
        for status in TicketStatus:
            if self.can_change_to(status):
                allowed.add(status)
        return allowed

    def _touch(self):
        self.update_date = datetime.now()

    def set_contents(self, contents):
        if not contents:
            raise ContentError("La description doit contenir au moins un texte ou une image.")
        self.contents = list(contents)

    def update_details(self, title, priority, contents):
        self.set_contents(contents)
        self.title = (title or "").strip()
        self.priority = priority
        self._touch()

    def assign_to(self, user):
        if not self.allows(Action.ASSIGN):
            raise InvalidTransition(f"Le ticket #{self.ticket_id} est « {self.status.label} » : "
                                    f"il ne peut plus être assigné.")
        self.assigned_to = user
        self.status = TicketStatus.ASSIGNE
        self._touch()

    def update_status(self, status):
        if status is self.status:
            return
        if not self.can_change_to(status):
            raise InvalidTransition(f"Transition interdite pour le ticket #{self.ticket_id} : "
                                    f"« {self.status.label} » → « {status.label} ».")
        if status is TicketStatus.OUVERT:
            self.assigned_to = None
        self.status = status
        self._touch()

    def add_comment(self, author, text):
        text = (text or "").strip()
        comment = Comment(author, text, datetime.now())
        self.comments.append(comment)
        self._touch()
        return comment

    def add_content(self, content):
        self.contents.append(content)
        self._touch()

    def content_summary(self):
        counts = {}
        for content in self.contents:
            if content.type_label in counts:
                counts[content.type_label] += 1
            else:
                counts[content.type_label] = 1
        parts = []
        for label, count in counts.items():
            if label == "Texte":
                parts.append("Texte")
            elif count > 1:
                parts.append(f"{count} {label.lower()}s")
            else:
                parts.append(f"{count} {label.lower()}")
        return " + ".join(parts)

    def create_memento(self):
        return TicketMemento(self)

    def restore(self, memento):
        self.title = memento.title
        self.priority = memento.priority
        self.status = memento.status
        self.assigned_to = memento.assigned_to
        self.contents = list(memento.contents)
        self.comments = list(memento.comments)
        self._touch()
