from abc import ABC, abstractmethod
from enum import Enum

from Gestion.observateur import ValidationError


class Action(Enum):
    CREATE = "Créer un ticket"
    VIEW = "Consulter le ticket"
    VIEW_ALL = "Voir tous les tickets"
    EDIT = "Modifier le ticket"
    COMMENT = "Commenter"
    ASSIGN = "Assigner"
    SUBMIT = "Soumettre pour validation"
    VALIDATE = "Valider"
    REJECT = "Refuser la résolution"
    CLOSE = "Fermer le ticket"
    REOPEN = "Rouvrir"
    CHANGE_STATUS = "Changer le statut"

    @property
    def label(self) -> str:
        return self.value


class Person(ABC):
    role = "Personne"

    def __init__(self, person_id: int, name: str, email: str, system=None):
        errors = {}
        if not name or not name.strip():
            errors["name"] = "Le nom est obligatoire."
        if not email or not email.strip():
            errors["email"] = "Le courriel est obligatoire."
        if errors:
            raise ValidationError(errors)
        self.person_id = person_id
        self.name = name.strip()
        self.email = email.strip().lower()
        self.system = system

    @abstractmethod
    def can(self, action: Action, ticket=None) -> bool:
        pass

    @property
    def is_admin(self) -> bool:
        return False

    def view_ticket(self, ticket_id: int):
        return self.system.get_ticket(self, ticket_id)

    def update_ticket(self, ticket_id: int, title: str, priority, contents):
        return self.system.update_ticket(self, ticket_id, title, priority, contents)

    def __str__(self) -> str:
        return self.name


class User(Person):
    role = "Utilisateur"

    def create_ticket(self, title: str, priority, contents):
        return self.system.create_ticket(self, title, priority, contents)

    def is_involved(self, ticket) -> bool:
        return ticket.author is self or ticket.assigned_to is self

    def can(self, action: Action, ticket=None) -> bool:
        if action is Action.CREATE:
            return True
        if ticket is None:
            return False
        if action in (Action.VIEW, Action.COMMENT):
            return self.is_involved(ticket)
        if action is Action.EDIT:
            return ticket.author is self
        if action is Action.SUBMIT:
            return ticket.assigned_to is self
        return False
