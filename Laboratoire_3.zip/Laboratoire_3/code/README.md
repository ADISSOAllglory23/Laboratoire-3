# Gestionnaire de tickets — Laboratoire 3 (6GEI311)

Interface graphique **tkinter** (application locale) intégrée à la logique métier
du laboratoire 2 : création de tickets dont la description combine **texte et
images**, visualisation des descriptions, rôles Utilisateur / Administrateur,
cycle de vie (Ouvert → Assigné → En validation → Terminé), commentaires,
annulation (Ctrl+Z).

## Installation

```bash
python -m venv .venv
# Windows : .venv\Scripts\activate      macOS/Linux : source .venv/bin/activate
pip install -r requirements.txt
```


## Lancement

```bash
python main.py
```

L'application démarre vide et rien n'est conservé à la fermeture : à chaque
lancement, créez vous-même les comptes depuis la fenêtre d'accueil
(« Créer un compte… », rôle Utilisateur ou Administrateur).

Scénario conseillé : créer un utilisateur et un administrateur, ouvrir leurs
deux sessions en même temps, créer un ticket (texte + image) avec
l'utilisateur, puis l'assigner avec l'administrateur : la liste de
l'utilisateur se met à jour toute seule (patron Observateur).



## Structure (MVC)

```
main.py                    assemblage modèle / contrôleurs / vue
Modele/                    classes du laboratoire 2, améliorées (aucune dépendance à tkinter)
  Ticket.py                Ticket, Comment, TicketMemento, TicketStatus (cycle de vie), Priority (labo 2 : Ticket.py)
  Content.py               TicketContent, TextContent, ImageContent, VideoContent, fabrique (labo 2 : Content.py)
  User.py                  Action, Person, User (labo 2 : User.py)
  Admin.py                 Admin (labo 2 : Admin.py)
Gestion/                   ajouts du laboratoire 3 pour relier le métier à l'interface
  systeme_tickets.py       TicketSystem : façade (comptes, tickets, droits), sujet observé
  observateur.py           Subject, Observer, BusinessEvent, exceptions métier
  style.py                 couleurs, polices et styles de l'interface
Controlleur/
  controleur_tickets.py    actions d'une session sur les tickets, annulation (Ctrl+Z)
  controleur_comptes.py    comptes et ouverture de sessions
Vue/
  application.py           application, accueil, fenêtre de session, actions des boutons
  dialogues.py             formulaire de ticket et fenêtres compte, assigner, statut, raison
  fiche_ticket.py          fiche du ticket (description, commentaires, actions)
  outils.py                zone défilante, chargement des images, dates
```
