import tkinter as tk
from tkinter import messagebox, ttk

from Gestion import BusinessError, EventType, Observer
from Gestion.style import COULEURS_PRIORITES, COULEURS_STATUTS, appliquer_style
from Modele import Action

from .dialogues import AccountDialog, AssignDialog, ReasonDialog, StatusDialog, TicketFormDialog
from .fiche_ticket import TicketDetailWindow
from .outils import format_date


class TicketActions:
    def __init__(self, controller, feedback, open_detail):
        self.controller = controller
        self.feedback = feedback
        self.open_detail = open_detail

    def buttons(self):
        return [
            (Action.EDIT, "Modifier…", self.edit),
            (Action.SUBMIT, "Soumettre pour validation", self.submit),
            (Action.ASSIGN, "Assigner…", self.assign),
            (Action.VALIDATE, "Valider", self.validate),
            (Action.REJECT, "Refuser…", self.reject),
            (Action.CHANGE_STATUS, "Changer le statut…", self.change_status),
            (Action.REOPEN, "Rouvrir", self.reopen),
            (Action.CLOSE, "Fermer…", self.close),
        ]

    def run(self, parent, operation, ticket_id):
        try:
            message = operation(ticket_id)
        except BusinessError as error:
            messagebox.showerror("Action impossible", str(error), parent=parent)
            self.feedback(str(error), error=True)
            return
        self.feedback(message)

    def show(self, dialog):
        message = dialog.show()
        if message:
            self.feedback(message)

    def new_ticket(self, parent):
        TicketFormDialog(parent, self.controller, on_saved=self.ticket_created)

    def ticket_created(self, ticket):
        self.feedback(f"Ticket #{ticket.ticket_id} créé : « {ticket.title} ».")
        self.open_detail(ticket.ticket_id)

    def edit(self, parent, ticket_id):
        TicketFormDialog(parent, self.controller, self.controller.ticket(ticket_id),
                         on_saved=self.ticket_saved)

    def ticket_saved(self, ticket):
        self.feedback(f"Ticket #{ticket.ticket_id} enregistré.")

    def assign(self, parent, ticket_id):
        self.show(AssignDialog(parent, self.controller, ticket_id,
                               lambda user_id: self.controller.assign(ticket_id, user_id)))

    def change_status(self, parent, ticket_id):
        self.show(StatusDialog(parent, self.controller, ticket_id,
                               lambda label: self.controller.change_status(ticket_id, label)))

    def submit(self, parent, ticket_id):
        question = (f"Soumettre le ticket #{ticket_id} pour validation ?\n\n"
                    "Un administrateur vérifiera la résolution. Vous pourrez annuler "
                    "cette action avec Ctrl+Z.")
        if messagebox.askyesno("Soumettre pour validation", question, parent=parent):
            self.run(parent, self.controller.submit_for_validation, ticket_id)

    def validate(self, parent, ticket_id):
        self.run(parent, self.controller.validate, ticket_id)

    def reopen(self, parent, ticket_id):
        self.run(parent, self.controller.reopen, ticket_id)

    def reject(self, parent, ticket_id):
        self.show(ReasonDialog(parent, "Refuser la résolution",
                               f"Pourquoi refuser la résolution du ticket #{ticket_id} ?",
                               "Refuser", lambda reason: self.controller.reject(ticket_id, reason),
                               "Le ticket retournera « Assigné » à son responsable."))

    def close(self, parent, ticket_id):
        self.show(ReasonDialog(parent, "Fermer le ticket", f"Fermer #{ticket_id}",
                               "Fermer le ticket",
                               lambda reason: self.controller.close(ticket_id, reason),
                               "Le ticket passera à « Terminé » sans validation (doublon, "
                               "demande invalide, problème disparu, ...)."))

    def comment(self, parent, ticket_id, text):
        try:
            self.controller.add_comment(ticket_id, text)
        except BusinessError as error:
            messagebox.showerror("Action impossible", str(error), parent=parent)
            self.feedback(str(error), error=True)
            return False
        self.feedback(f"Commentaire ajouté au ticket #{ticket_id}.")
        return True

    def undo(self, parent):
        if not self.controller.can_undo():
            self.feedback("Aucune action à annuler.")
            return
        try:
            message = self.controller.undo()
        except BusinessError as error:
            messagebox.showerror("Action impossible", str(error), parent=parent)
            self.feedback(str(error), error=True)
            return
        self.feedback(message)


class SessionWindow(tk.Toplevel, Observer):
    def __init__(self, master, controller, on_close=None):
        super().__init__(master)
        self.controller = controller
        self.actor = controller.actor
        self.is_admin = controller.is_admin
        self.on_close = on_close
        self.details = {}
        self.tool_buttons = []
        self.actions = TicketActions(controller, self.feedback, self.open_detail)

        self.title(f"Tickets — {self.actor.name} ({self.actor.role})")
        self.geometry("1180x660")

        if self.is_admin:
            scope = "Tous les tickets du système"
        else:
            scope = "Vos tickets : créés par vous ou assignés à vous"
        header = ttk.Frame(self, style="Entete.TFrame", padding=(15, 10))
        header.pack(fill="x")
        ttk.Label(header, text=f"Bonjour, {self.actor.name} ({self.actor.role})",
                  style="Entete.TLabel").pack(anchor="w")
        ttk.Label(header, text=scope, style="EnteteGris.TLabel").pack(anchor="w")

        self.build_toolbar()
        self.build_list()

        self.status_var = tk.StringVar()
        self.undo_var = tk.StringVar()
        bar = ttk.Frame(self, padding=(15, 5))
        bar.pack(fill="x", side="bottom")
        self.status_label = ttk.Label(bar, textvariable=self.status_var)
        self.status_label.pack(side="left")
        ttk.Label(bar, textvariable=self.undo_var).pack(side="right")

        if self.controller.can(Action.CREATE):
            self.bind("<Control-n>", lambda event: self.actions.new_ticket(self))
        self.bind("<Control-z>", lambda event: self.actions.undo(self))
        self.protocol("WM_DELETE_WINDOW", self.close)
        controller.subscribe(self)
        self.refresh()
        self.feedback(f"Session ouverte : {self.actor.name} ({self.actor.role}).")

    def build_toolbar(self):
        self.bar = ttk.Frame(self, padding=(15, 5))
        self.bar.pack(fill="x")

        if self.controller.can(Action.CREATE):
            ttk.Button(self.bar, text="+ Nouveau ticket", style="Accent.TButton",
                       command=lambda: self.actions.new_ticket(self)).pack(side="left", padx=(0, 6))
        open_button = ttk.Button(self.bar, text="Ouvrir", command=self.open_selected)
        open_button.pack(side="left", padx=(0, 6))
        self.tool_buttons.append((open_button, Action.VIEW))

        for action, text, method in self.actions.buttons():
            if self.is_admin and action == Action.SUBMIT:
                continue
            if not self.is_admin and action not in (Action.EDIT, Action.SUBMIT):
                continue
            self.add_tool_button(text, method, action)

        self.undo_button = ttk.Button(self.bar, text="Annuler la dernière action (Ctrl+Z)",
                                      command=lambda: self.actions.undo(self))
        self.undo_button.pack(side="right")

    def add_tool_button(self, text, method, action):
        button = ttk.Button(self.bar, text=text, command=lambda: method(self, self.selected_id()))
        if action == Action.CLOSE:
            button.configure(style="Danger.TButton")
        button.pack(side="left", padx=(0, 6))
        self.tool_buttons.append((button, action))

    def build_list(self):
        if self.is_admin:
            self.columns = ["N°", "Titre", "Créé par", "Assigné à", "Priorité", "Statut",
                            "Description", "Mis à jour"]
        else:
            self.columns = ["N°", "Titre", "Mon lien", "Assigné à", "Priorité", "Statut",
                            "Description", "Mis à jour"]

        frame = ttk.Frame(self, padding=(15, 5))
        frame.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(frame, columns=self.columns, show="headings", selectmode="browse")
        for column in self.columns:
            self.tree.heading(column, text=column)
            self.tree.column(column, width=120)
        self.tree.column("N°", width=44, anchor="center")
        self.tree.column("Titre", width=260)
        for statut, couleur in COULEURS_STATUTS.items():
            self.tree.tag_configure(statut, background=couleur)
        for priorite, couleur in COULEURS_PRIORITES.items():
            self.tree.tag_configure(priorite, foreground=couleur)
        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.tree.bind("<<TreeviewSelect>>", lambda event: self.update_buttons())
        self.tree.bind("<Double-1>", lambda event: self.open_selected())
        self.tree.bind("<Return>", lambda event: self.open_selected())

        self.count_label = ttk.Label(self, padding=(15, 5))
        self.count_label.pack(anchor="w")

    def row_values(self, ticket):
        if ticket.assigned_to is None:
            assignee = "—"
        else:
            assignee = ticket.assigned_to.name

        if self.is_admin:
            second = ticket.author.name
        else:
            links = []
            if ticket.author is self.actor:
                links.append("Créé par moi")
            if ticket.assigned_to is self.actor:
                links.append("Assigné à moi")
            second = " · ".join(links)

        return [ticket.ticket_id, ticket.title, second, assignee, ticket.priority.label,
                ticket.status.label, ticket.content_summary(), format_date(ticket.update_date)]

    def refresh(self):
        if not self.winfo_exists():
            return
        selected = self.selected_id()
        tickets = self.controller.tickets()
        self.tree.delete(*self.tree.get_children())
        for ticket in tickets:
            self.tree.insert("", "end", iid=str(ticket.ticket_id), values=self.row_values(ticket),
                             tags=(ticket.status.name, ticket.priority.name))
        if selected is not None and self.tree.exists(str(selected)):
            self.tree.selection_set(str(selected))

        if len(tickets) == 0:
            self.count_label.configure(text="Aucun ticket pour l'instant.")
        else:
            self.count_label.configure(
                text=f"{len(tickets)} ticket(s)  ·  Double-clic ou Entrée pour ouvrir un ticket")
        self.update_buttons()

    def selected_id(self):
        selection = self.tree.selection()
        if selection:
            return int(selection[0])
        return None

    def update_buttons(self):
        ticket = None
        if self.selected_id() is not None:
            ticket = self.controller.ticket(self.selected_id())
        for button, action in self.tool_buttons:
            if ticket is not None and self.controller.can(action, ticket):
                button.state(["!disabled"])
            else:
                button.state(["disabled"])

        if self.controller.can_undo():
            self.undo_button.state(["!disabled"])
            self.undo_var.set(f"Ctrl+Z annulera : {self.controller.undo_label()}")
        else:
            self.undo_button.state(["disabled"])
            self.undo_var.set("Aucune action à annuler")

    def feedback(self, message, error=False):
        if not self.winfo_exists():
            return
        if error:
            message = "Erreur : " + message
            self.status_label.configure(style="Erreur.TLabel")
        else:
            self.status_label.configure(style="Succes.TLabel")
        self.status_var.set(message)
        self.update_buttons()

    def open_selected(self):
        if self.selected_id() is not None:
            self.open_detail(self.selected_id())

    def open_detail(self, ticket_id):
        window = self.details.get(ticket_id)
        if window is not None and window.winfo_exists():
            window.deiconify()
            window.lift()
            return window
        window = TicketDetailWindow(self, self.controller, self.actions, ticket_id,
                                    on_close=self.detail_closed)
        self.details[ticket_id] = window
        return window

    def detail_closed(self, ticket_id):
        if ticket_id in self.details:
            del self.details[ticket_id]

    def on_event(self, event):
        if not self.winfo_exists():
            return
        self.refresh()
        if event.actor is not self.actor and event.ticket_id is not None:
            for ticket in self.controller.tickets():
                if ticket.ticket_id == event.ticket_id:
                    self.feedback(f"Mise à jour : {event.message}")
        elif event.type == EventType.ACCOUNT_CREATED and self.is_admin:
            self.feedback(event.message)

    def close(self):
        self.controller.unsubscribe(self)
        for window in list(self.details.values()):
            if window.winfo_exists():
                window.close()
        if self.on_close:
            self.on_close()
        self.destroy()


class LauncherView(ttk.Frame, Observer):
    def __init__(self, root, app_controller, open_session):
        super().__init__(root, padding=20)
        self.app_controller = app_controller
        self.open_session = open_session
        self.pack(fill="both", expand=True)

        ttk.Label(self, text="Gestionnaire de tickets", style="Titre.TLabel").pack(anchor="w")
        ttk.Label(self, text="Créez vos comptes, puis choisissez-en un pour ouvrir une session.\n"
                             "Vous pouvez ouvrir plusieurs sessions en même temps "
                             "(ex. un utilisateur et un administrateur).").pack(anchor="w", pady=(4, 14))

        self.tree = ttk.Treeview(self, columns=("Nom", "Courriel", "Rôle"), show="headings",
                                 height=8, selectmode="browse")
        self.tree.heading("Nom", text="Nom")
        self.tree.heading("Courriel", text="Courriel")
        self.tree.heading("Rôle", text="Rôle")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", lambda event: self.open_selected())
        self.tree.bind("<Return>", lambda event: self.open_selected())
        self.tree.bind("<<TreeviewSelect>>", lambda event: self.update_button())

        buttons = ttk.Frame(self, padding=(0, 14, 0, 0))
        buttons.pack(fill="x")
        self.create_button = ttk.Button(buttons, text="Créer un compte… (Ctrl+N)",
                                        command=self.create_account)
        self.create_button.pack(side="left")
        self.open_button = ttk.Button(buttons, text="Ouvrir la session", style="Accent.TButton",
                                      command=self.open_selected)
        self.open_button.pack(side="right")

        root.bind("<Control-n>", lambda event: self.create_account())
        app_controller.subscribe(self)
        self.refresh()
        if self.tree.get_children():
            self.tree.focus_set()
        else:
            self.create_button.focus_set()

    def refresh(self, select_id=None):
        self.tree.delete(*self.tree.get_children())
        for person in self.app_controller.accounts():
            self.tree.insert("", "end", iid=str(person.person_id),
                             values=(person.name, person.email, person.role))
        children = self.tree.get_children()
        if select_id is not None and self.tree.exists(str(select_id)):
            self.tree.selection_set(str(select_id))
            self.tree.focus(str(select_id))
        elif children:
            self.tree.selection_set(children[0])
            self.tree.focus(children[0])
        self.update_button()

    def update_button(self):
        if self.tree.selection():
            self.open_button.state(["!disabled"])
        else:
            self.open_button.state(["disabled"])

    def open_selected(self):
        selection = self.tree.selection()
        if selection:
            self.open_session(int(selection[0]))

    def create_account(self):
        dialog = AccountDialog(self, self.app_controller.roles(), self.save_account)
        person = dialog.show()
        if person is not None:
            self.refresh(select_id=person.person_id)

    def save_account(self, values):
        return self.app_controller.create_account(values["name"], values["email"], values["role"])

    def on_event(self, event):
        if event.type == EventType.ACCOUNT_CREATED:
            self.refresh(select_id=event.actor.person_id)


class TicketApp:
    def __init__(self, app_controller):
        self.app_controller = app_controller
        self.root = tk.Tk()
        appliquer_style(self.root)
        self.root.title("Gestionnaire de tickets — 6GEI311")
        self.sessions = {}
        self.launcher = LauncherView(self.root, app_controller, self.open_session)

    def open_session(self, person_id):
        window = self.sessions.get(person_id)
        if window is not None and window.winfo_exists():
            window.deiconify()
            window.lift()
            return window
        controller = self.app_controller.open_session(person_id)
        window = SessionWindow(self.root, controller,
                               on_close=lambda: self.session_closed(person_id))
        self.sessions[person_id] = window
        return window

    def session_closed(self, person_id):
        if person_id in self.sessions:
            del self.sessions[person_id]

    def run(self):
        self.root.mainloop()
