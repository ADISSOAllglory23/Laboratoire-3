import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from Gestion import BusinessError, ValidationError

from .outils import PIL_AVAILABLE, ScrollableFrame, load_photo, prepare_window

if PIL_AVAILABLE:
    IMAGE_TYPES = [("Images", "*.png *.jpg *.jpeg *.gif *.bmp"), ("Tous les fichiers", "*.*")]
else:
    IMAGE_TYPES = [("Images PNG/GIF", "*.png *.gif"), ("Tous les fichiers", "*.*")]


class BaseDialog(tk.Toplevel):
    def __init__(self, master, title, ok_text, on_submit):
        super().__init__(master)
        self.title(title)
        self.transient(master.winfo_toplevel())
        self.resizable(False, False)
        self.on_submit = on_submit
        self.result = None

        body = ttk.Frame(self, padding=20)
        body.pack(fill="both", expand=True)
        self.build(body)

        self.error_var = tk.StringVar()
        ttk.Label(self, textvariable=self.error_var, style="Erreur.TLabel", padding=(20, 0),
                  wraplength=440).pack(fill="x")

        buttons = ttk.Frame(self, padding=(20, 10))
        buttons.pack(fill="x")
        self.ok_button = ttk.Button(buttons, text=ok_text, style="Accent.TButton", command=self.ok)
        self.ok_button.pack(side="right")
        ttk.Button(buttons, text="Annuler", command=self.cancel).pack(side="right", padx=8)

        self.bind("<Return>", self.on_return)
        prepare_window(self, master, self.cancel)
        self.first_field().focus_set()

    def build(self, body):
        pass

    def collect(self):
        return None

    def first_field(self):
        return self.ok_button

    def on_return(self, event):
        if not isinstance(event.widget, tk.Text):
            self.ok()

    def ok(self):
        self.error_var.set("")
        try:
            values = self.collect()
            self.result = self.on_submit(values)
        except ValidationError as error:
            self.error_var.set(" ".join(error.errors.values()))
            return
        except BusinessError as error:
            self.error_var.set(str(error))
            return
        self.destroy()

    def cancel(self):
        self.result = None
        self.destroy()

    def show(self):
        self.grab_set()
        self.wait_window()
        return self.result


class AccountDialog(BaseDialog):
    def __init__(self, master, roles, on_submit):
        self.roles = roles
        super().__init__(master, "Créer un compte", "Créer le compte", on_submit)

    def build(self, body):
        self.name_var = tk.StringVar()
        self.email_var = tk.StringVar()
        self.role_var = tk.StringVar(value=self.roles[0])

        ttk.Label(body, text="Nom complet *").grid(row=0, column=0, sticky="w", pady=4)
        self.name_entry = ttk.Entry(body, textvariable=self.name_var, width=36)
        self.name_entry.grid(row=0, column=1, pady=4)
        ttk.Label(body, text="Courriel *").grid(row=1, column=0, sticky="w", pady=4)
        ttk.Entry(body, textvariable=self.email_var, width=36).grid(row=1, column=1, pady=4)
        ttk.Label(body, text="Rôle").grid(row=2, column=0, sticky="nw", pady=4)

        hints = {"Utilisateur": "crée des tickets et traite ceux qui lui sont assignés",
                 "Administrateur": "voit tous les tickets, assigne, valide et ferme"}
        row = 2
        for role in self.roles:
            ttk.Radiobutton(body, text=f"{role} — {hints[role]}", value=role,
                            variable=self.role_var).grid(row=row, column=1, sticky="w")
            row += 1

    def first_field(self):
        return self.name_entry

    def collect(self):
        return {"name": self.name_var.get(), "email": self.email_var.get(),
                "role": self.role_var.get()}


class AssignDialog(BaseDialog):
    def __init__(self, master, controller, ticket_id, on_submit):
        self.controller = controller
        self.ticket_id = ticket_id
        super().__init__(master, "Assigner le ticket", "Assigner", on_submit)

    def build(self, body):
        ttk.Label(body, text=f"Assigner #{self.ticket_id} à :").pack(anchor="w")
        ttk.Label(body, text="La colonne « Actifs » indique la charge actuelle de chaque "
                             "utilisateur.").pack(anchor="w", pady=(2, 10))
        self.tree = ttk.Treeview(body, columns=("name", "email", "active"), show="headings",
                                 height=6, selectmode="browse")
        self.tree.heading("name", text="Utilisateur")
        self.tree.heading("email", text="Courriel")
        self.tree.heading("active", text="Actifs")
        self.tree.column("name", width=160)
        self.tree.column("email", width=250)
        self.tree.column("active", width=70, anchor="center")

        current = self.controller.ticket(self.ticket_id).assigned_to
        for user, active in self.controller.assignable_users():
            self.tree.insert("", "end", iid=str(user.person_id),
                             values=(user.name, user.email, active))
            if user is current:
                self.tree.selection_set(str(user.person_id))
        if not self.tree.selection() and self.tree.get_children():
            self.tree.selection_set(self.tree.get_children()[0])
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", lambda event: self.ok())

    def first_field(self):
        return self.tree

    def collect(self):
        selection = self.tree.selection()
        if not selection:
            raise ValidationError({"assignee": "Choisissez un utilisateur."})
        return int(selection[0])


class StatusDialog(BaseDialog):
    def __init__(self, master, controller, ticket_id, on_submit):
        self.controller = controller
        self.ticket_id = ticket_id
        super().__init__(master, "Changer le statut", "Appliquer", on_submit)
        if not self.status_var.get():
            self.ok_button.state(["disabled"])

    def build(self, body):
        ticket = self.controller.ticket(self.ticket_id)
        allowed = []
        for status in self.controller.allowed_statuses(self.ticket_id):
            allowed.append(status.label)

        ttk.Label(body, text=f"Nouveau statut pour #{self.ticket_id}").pack(anchor="w")
        ttk.Label(body, text=f"Statut actuel : {ticket.status.label}").pack(anchor="w", pady=(6, 12))

        self.status_var = tk.StringVar()
        for label in self.controller.status_labels():
            if label in allowed:
                text = label
            elif label == "Assigné":
                text = f"{label}  —  utilisez « Assigner… » pour choisir un responsable"
            else:
                text = f"{label}  —  transition non permise depuis l'état actuel"
            button = ttk.Radiobutton(body, text=text, value=label, variable=self.status_var)
            button.pack(anchor="w", pady=2)
            if label not in allowed:
                button.state(["disabled"])
            elif self.status_var.get() == "":
                self.status_var.set(label)
        ttk.Label(body, text="Retour à « Ouvert » : le responsable est retiré.").pack(
            anchor="w", pady=(10, 0))

    def collect(self):
        if self.status_var.get() == "":
            raise ValidationError({"status": "Aucun changement de statut possible."})
        return self.status_var.get()


class ReasonDialog(BaseDialog):
    def __init__(self, master, title, prompt, ok_text, on_submit, detail=""):
        self.prompt = prompt
        self.detail = detail
        super().__init__(master, title, ok_text, on_submit)

    def build(self, body):
        ttk.Label(body, text=self.prompt).pack(anchor="w")
        if self.detail:
            ttk.Label(body, text=self.detail, wraplength=440).pack(anchor="w", pady=(2, 8))
        self.text = tk.Text(body, height=5, width=52, wrap="word")
        self.text.pack(fill="both", expand=True)
        ttk.Label(body, text="La raison sera ajoutée aux commentaires du ticket.").pack(
            anchor="w", pady=(6, 0))

    def first_field(self):
        return self.text

    def collect(self):
        reason = self.text.get("1.0", "end-1c").strip()
        if reason == "":
            raise ValidationError({"reason": "La raison est obligatoire."})
        return reason


class BlockEditor(tk.Frame):
    label = "Bloc"

    def __init__(self, form, master):
        super().__init__(master, highlightthickness=1, padx=10, pady=8)
        header = tk.Frame(self)
        header.pack(fill="x", pady=(0, 6))
        self.title_label = ttk.Label(header, text=self.label)
        self.title_label.pack(side="left")
        ttk.Button(header, text="× Retirer",
                   command=lambda: form.remove_block(self)).pack(side="right")
        self.down_button = ttk.Button(header, text="↓", width=3,
                                      command=lambda: form.move_block(self, 1))
        self.down_button.pack(side="right", padx=4)
        self.up_button = ttk.Button(header, text="↑", width=3,
                                    command=lambda: form.move_block(self, -1))
        self.up_button.pack(side="right")

    def set_position(self, number, total):
        self.title_label.configure(text=f"{number}. {self.label}")
        if number == 1:
            self.up_button.state(["disabled"])
        else:
            self.up_button.state(["!disabled"])
        if number == total:
            self.down_button.state(["disabled"])
        else:
            self.down_button.state(["!disabled"])

    def get_data(self):
        return {}

    def focus_editor(self):
        pass


class TextBlockEditor(BlockEditor):
    label = "Paragraphe"

    def __init__(self, form, master, text=""):
        super().__init__(form, master)
        self.form = form
        self.text = tk.Text(self, height=5, wrap="word", undo=True)
        self.text.pack(fill="x")
        self.text.insert("1.0", text)
        self.text.bind("<Control-Return>", self.on_ctrl_return)

    def on_ctrl_return(self, event):
        self.form.submit()
        return "break"

    def get_data(self):
        return {"kind": "texte", "text": self.text.get("1.0", "end-1c")}

    def focus_editor(self):
        self.text.focus_set()


class ImageBlockEditor(BlockEditor):
    label = "Image"

    def __init__(self, form, master, path):
        super().__init__(form, master)
        self.path = path
        self.photo = load_photo(self, path, 240, 150)
        tk.Label(self, image=self.photo).pack(side="left", anchor="n")
        ttk.Label(self, text=os.path.basename(path)).pack(side="left", anchor="n", padx=12)

    def get_data(self):
        return {"kind": "image", "path": self.path}


class TicketFormDialog(tk.Toplevel):
    def __init__(self, master, controller, ticket=None, on_saved=None):
        super().__init__(master)
        self.controller = controller
        self.ticket = ticket
        self.on_saved = on_saved
        self.blocks = []

        if ticket is None:
            title = "Nouveau ticket"
            button_text = "Créer le ticket"
        else:
            title = f"Modifier le ticket #{ticket.ticket_id}"
            button_text = "Enregistrer"
        self.title(title)
        self.geometry("780x760")
        self.transient(master.winfo_toplevel())

        ttk.Label(self, text="Décrivez le problème avec du texte et des images, dans l'ordre "
                             "où ils doivent s'afficher.", padding=(20, 15, 20, 5)).pack(anchor="w")
        self.build_fields()
        self.build_blocks_area()

        footer = ttk.Frame(self, padding=(20, 12))
        footer.pack(fill="x")
        ttk.Label(footer, text="Ctrl+Entrée : enregistrer   ·   Échap : annuler").pack(side="left")
        ttk.Button(footer, text=button_text, style="Accent.TButton",
                   command=self.submit).pack(side="right")
        ttk.Button(footer, text="Annuler", command=self.cancel).pack(side="right", padx=8)

        if ticket is None:
            self.add_text_block(focus=False)
        else:
            self.title_var.set(ticket.title)
            self.priority_var.set(ticket.priority.label)
            for content in ticket.contents:
                data = content.to_dict()
                if data["kind"] == "texte":
                    self.add_text_block(data["text"], focus=False)
                elif data["kind"] == "image":
                    self.add_image_block(data["path"])
        self.initial_data = self.get_form_data()

        self.bind("<Control-Return>", lambda event: self.submit())
        prepare_window(self, master, self.cancel)
        self.title_entry.focus_set()

    def build_fields(self):
        fields = ttk.Frame(self, padding=(20, 5))
        fields.pack(fill="x")
        fields.columnconfigure(1, weight=1)

        ttk.Label(fields, text="Titre", style="Gras.TLabel").grid(row=0, column=0, sticky="w")
        self.title_var = tk.StringVar()
        self.title_entry = ttk.Entry(fields, textvariable=self.title_var)
        self.title_entry.grid(row=0, column=1, sticky="ew", padx=(12, 0))

        ttk.Label(fields, text="Priorité", style="Gras.TLabel").grid(row=1, column=0, sticky="w", pady=(6, 0))
        self.priority_var = tk.StringVar(value="Normale")
        ttk.Combobox(fields, textvariable=self.priority_var, state="readonly", width=14,
                     values=self.controller.priority_labels()).grid(
            row=1, column=1, sticky="w", padx=(12, 0), pady=(6, 0))

        ttk.Label(fields, text="Description *", style="Gras.TLabel").grid(row=2, column=0, sticky="w", pady=(12, 4))
        self.count_var = tk.StringVar()
        ttk.Label(fields, textvariable=self.count_var).grid(
            row=2, column=1, sticky="w", padx=(12, 0), pady=(12, 4))

    def build_blocks_area(self):
        self.scroll = ScrollableFrame(self)
        self.scroll.pack(fill="both", expand=True, padx=20)
        self.scroll.inner.columnconfigure(0, weight=1)

        tools = ttk.Frame(self, padding=(20, 8, 20, 0))
        tools.pack(fill="x")
        ttk.Button(tools, text="+ Paragraphe", command=self.add_text_block).pack(side="left")
        ttk.Button(tools, text="+ Image…", command=self.add_image_block).pack(side="left", padx=6)
        ttk.Button(tools, text="Importer un fichier .txt…",
                   command=self.import_text_file).pack(side="left")

        self.error_var = tk.StringVar()
        ttk.Label(self, textvariable=self.error_var, style="Erreur.TLabel", padding=(20, 6, 20, 0),
                  wraplength=720).pack(fill="x")

    def add_text_block(self, text="", focus=True):
        block = TextBlockEditor(self, self.scroll.inner, text)
        self.add_block(block, focus)

    def add_image_block(self, path=None):
        if path is None:
            path = filedialog.askopenfilename(parent=self, title="Choisir une image",
                                              filetypes=IMAGE_TYPES)
            if not path:
                return
        try:
            block = ImageBlockEditor(self, self.scroll.inner, path)
        except (OSError, tk.TclError):
            self.error_var.set(f"Impossible d'ouvrir « {os.path.basename(path)} » comme image.")
            return
        self.add_block(block, True)

    def import_text_file(self):
        path = filedialog.askopenfilename(parent=self, title="Importer un fichier texte",
                                          filetypes=[("Texte", "*.txt"), ("Tous les fichiers", "*.*")])
        if not path:
            return
        try:
            self.add_text_block(self.controller.read_text_file(path))
        except BusinessError as error:
            self.error_var.set(str(error))

    def add_block(self, block, focus):
        self.blocks.append(block)
        self.error_var.set("")
        self.show_blocks()
        if focus:
            block.focus_editor()
            self.scroll.scroll_to_bottom()

    def move_block(self, block, step):
        index = self.blocks.index(block)
        new_index = index + step
        if 0 <= new_index < len(self.blocks):
            self.blocks[index] = self.blocks[new_index]
            self.blocks[new_index] = block
            self.show_blocks()

    def remove_block(self, block):
        self.blocks.remove(block)
        block.destroy()
        self.show_blocks()

    def show_blocks(self):
        texts = 0
        images = 0
        number = 1
        for block in self.blocks:
            block.grid(row=number, column=0, sticky="ew", pady=(0, 10))
            block.set_position(number, len(self.blocks))
            number += 1
            if isinstance(block, TextBlockEditor):
                texts += 1
            else:
                images += 1
        self.count_var.set(f"{texts} paragraphe(s), {images} image(s)")

    def get_form_data(self):
        blocks = []
        for block in self.blocks:
            blocks.append(block.get_data())
        return (self.title_var.get(), self.priority_var.get(), blocks)

    def submit(self):
        self.error_var.set("")
        title, priority, blocks = self.get_form_data()
        try:
            if self.ticket is None:
                ticket = self.controller.create_ticket(title, priority, blocks)
            else:
                ticket = self.controller.update_ticket(self.ticket.ticket_id, title, priority, blocks)
        except ValidationError as error:
            self.error_var.set(" ".join(error.errors.values()))
            return
        except BusinessError as error:
            self.error_var.set(str(error))
            return
        if self.on_saved:
            self.on_saved(ticket)
        self.destroy()

    def cancel(self):
        if self.get_form_data() != self.initial_data:
            if not messagebox.askyesno("Abandonner les modifications ?",
                                       "Le ticket n'a pas été enregistré. Vos modifications "
                                       "seront perdues.", parent=self):
                return
        self.destroy()
