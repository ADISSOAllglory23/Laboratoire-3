import tkinter as tk
from tkinter import ttk

from Gestion import BusinessError, ContentError, Observer
from Modele import Action, TicketStatus

from .outils import ScrollableFrame, format_date, load_photo, prepare_window


def show_content(parent, content):
    frame = ttk.Frame(parent)
    if content.kind == "texte":
        ttk.Label(frame, text=content.load(), wraplength=560, justify="left").pack(anchor="w")
    elif content.kind == "image":
        try:
            photo = load_photo(parent, content.load(), 560, 360)
        except (ContentError, OSError, tk.TclError):
            ttk.Label(frame, text=f"[Image indisponible] {content.file_name}").pack(anchor="w")
            return frame
        label = tk.Label(frame, image=photo)
        label.image = photo
        label.pack(anchor="w")
        ttk.Label(frame, text=content.file_name).pack(anchor="w", pady=(4, 0))
    else:
        ttk.Label(frame, text=f"[{content.type_label}] {content.path}").pack(anchor="w")
    return frame


class TicketDetailWindow(tk.Toplevel, Observer):
    def __init__(self, master, controller, actions, ticket_id, on_close=None):
        super().__init__(master)
        self.controller = controller
        self.actions = actions
        self.ticket_id = ticket_id
        self.on_close = on_close
        self.geometry("1120x760")

        self.header = ttk.Frame(self, padding=(20, 15))
        self.header.pack(fill="x")

        middle = ttk.Frame(self, padding=(15, 0))
        middle.pack(fill="both", expand=True)
        middle.columnconfigure(0, weight=3)
        middle.columnconfigure(1, weight=2)
        middle.rowconfigure(1, weight=1)

        self.description_title = ttk.Label(middle, text="Description", style="Gras.TLabel")
        self.description_title.grid(row=0, column=0, sticky="w", pady=5)
        self.description = ScrollableFrame(middle)
        self.description.grid(row=1, column=0, sticky="nsew", padx=(0, 10))

        self.comments_title = ttk.Label(middle, text="Commentaires", style="Gras.TLabel")
        self.comments_title.grid(row=0, column=1, sticky="w", pady=5)
        self.comments = ScrollableFrame(middle)
        self.comments.grid(row=1, column=1, sticky="nsew")

        comment_box = ttk.Frame(middle)
        comment_box.grid(row=2, column=1, sticky="ew", pady=8)
        ttk.Label(comment_box, text="Ajouter un commentaire (Ctrl+Entrée pour envoyer)").pack(anchor="w")
        self.comment_text = tk.Text(comment_box, height=3, width=30, wrap="word")
        self.comment_text.pack(fill="x", pady=4)
        self.comment_text.bind("<Control-Return>", self.on_ctrl_return)
        self.comment_button = ttk.Button(comment_box, text="Commenter", style="Accent.TButton",
                                         command=self.send_comment)
        self.comment_button.pack(anchor="e")

        self.action_bar = ttk.Frame(self, padding=(15, 10))
        self.action_bar.pack(fill="x")

        controller.subscribe(self)
        self.refresh()
        prepare_window(self, master, self.close)

    def refresh(self):
        try:
            ticket = self.controller.ticket(self.ticket_id)
        except BusinessError as error:
            self.actions.feedback(f"Fiche #{self.ticket_id} fermée : {error}", error=True)
            self.close()
            return
        self.title(f"Ticket #{ticket.ticket_id} — {ticket.title}")
        self.show_header(ticket)
        self.show_description(ticket)
        self.show_comments(ticket)
        self.show_actions(ticket)

    def show_header(self, ticket):
        for child in self.header.winfo_children():
            child.destroy()

        ttk.Label(self.header, text=f"#{ticket.ticket_id}   {ticket.title}", style="Titre.TLabel").grid(
            row=0, column=0, columnspan=4, sticky="w")
        ttk.Label(self.header, text=ticket.status.label,
                  style=ticket.status.name + ".TLabel").grid(row=0, column=4, sticky="e")

        if ticket.assigned_to is None:
            assignee = "Non assigné"
        else:
            assignee = ticket.assigned_to.name
        infos = [
            ("Priorité", ticket.priority.label, ticket.priority.name + ".TLabel"),
            ("Créé par", f"{ticket.author.name}, le {format_date(ticket.creation_date)}", "TLabel"),
            ("Assigné à", assignee, "TLabel"),
            ("Mis à jour", format_date(ticket.update_date), "TLabel"),
        ]
        column = 0
        for name, value, style in infos:
            ttk.Label(self.header, text=name, style="Gris.TLabel").grid(row=1, column=column, sticky="w", padx=(0, 30), pady=(10, 0))
            ttk.Label(self.header, text=value, style=style).grid(row=2, column=column, sticky="w", padx=(0, 30))
            column += 1

        steps = []
        for status in TicketStatus:
            if status is ticket.status:
                steps.append(f"[{status.label}]")
            else:
                steps.append(status.label)
        ttk.Label(self.header, text="Cycle de vie : " + " › ".join(steps)).grid(
            row=3, column=0, columnspan=5, sticky="w", pady=(10, 0))

    def show_description(self, ticket):
        for child in self.description.inner.winfo_children():
            child.destroy()
        for content in ticket.contents:
            show_content(self.description.inner, content).pack(fill="x", anchor="w", pady=(0, 14))
        self.description_title.configure(text=f"Description  ·  {ticket.content_summary()}")
        self.description.scroll_to_top()

    def show_comments(self, ticket):
        for child in self.comments.inner.winfo_children():
            child.destroy()
        self.comments_title.configure(text=f"Commentaires ({len(ticket.comments)})")
        if not ticket.comments:
            ttk.Label(self.comments.inner, text="Aucun commentaire pour l'instant.").pack(anchor="w")
        for comment in ticket.comments:
            card = tk.Frame(self.comments.inner, highlightthickness=1, padx=10, pady=8)
            card.pack(fill="x", pady=(0, 8))
            author = f"{comment.author.name} · {comment.author.role} · {format_date(comment.date)}"
            tk.Label(card, text=author).pack(anchor="w")
            tk.Label(card, text=comment.text, wraplength=380, justify="left").pack(anchor="w", pady=(4, 0))

        if self.controller.can(Action.COMMENT, ticket):
            self.comment_button.state(["!disabled"])
        else:
            self.comment_button.state(["disabled"])
        self.comments.scroll_to_bottom()

    def show_actions(self, ticket):
        for child in self.action_bar.winfo_children():
            child.destroy()
        shown = 0
        for action, text, method in self.actions.buttons():
            if self.controller.actor.can(action, ticket):
                self.add_action_button(text, method, action, ticket.allows(action))
                shown += 1
        if shown == 0:
            ttk.Label(self.action_bar, text="Aucune action disponible pour votre rôle sur ce "
                                            "ticket.").pack(side="left")
        ttk.Button(self.action_bar, text="Retour (Échap)", command=self.close).pack(side="right")

    def add_action_button(self, text, method, action, enabled):
        button = ttk.Button(self.action_bar, text=text,
                            command=lambda: method(self, self.ticket_id))
        if action == Action.CLOSE:
            button.configure(style="Danger.TButton")
        button.pack(side="left", padx=(0, 6))
        if not enabled:
            button.state(["disabled"])

    def on_ctrl_return(self, event):
        self.send_comment()
        return "break"

    def send_comment(self):
        text = self.comment_text.get("1.0", "end-1c")
        if self.actions.comment(self, self.ticket_id, text):
            self.comment_text.delete("1.0", "end")

    def on_event(self, event):
        if event.ticket_id == self.ticket_id and self.winfo_exists():
            self.refresh()

    def close(self):
        self.controller.unsubscribe(self)
        if self.on_close:
            self.on_close(self.ticket_id)
        if self.winfo_exists():
            self.destroy()
