import tkinter as tk
from tkinter import ttk

try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False


def load_photo(master, path, max_width, max_height):
    if PIL_AVAILABLE:
        image = Image.open(path)
        image.thumbnail((max_width, max_height))
        return ImageTk.PhotoImage(image, master=master)

    photo = tk.PhotoImage(master=master, file=path)
    factor = 1
    while photo.width() / factor > max_width or photo.height() / factor > max_height:
        factor += 1
    return photo.subsample(factor)


def format_date(date):
    return date.strftime("%Y-%m-%d %H:%M")


def prepare_window(window, master, on_close):
    window.bind("<Escape>", lambda event: on_close())
    window.protocol("WM_DELETE_WINDOW", on_close)

    window.update_idletasks()
    parent = master.winfo_toplevel()
    width = max(window.winfo_width(), window.winfo_reqwidth())
    height = max(window.winfo_height(), window.winfo_reqheight())
    x = parent.winfo_rootx() + (parent.winfo_width() - width) // 2
    y = parent.winfo_rooty() + (parent.winfo_height() - height) // 3
    window.geometry(f"+{max(x, 0)}+{max(y, 0)}")


class ScrollableFrame(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.canvas = tk.Canvas(self, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.inner = tk.Frame(self.canvas)
        self.window_id = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")

        self.inner.bind("<Configure>", self.update_scroll_region)
        self.canvas.bind("<Configure>", self.update_width)
        self.canvas.bind("<Enter>", self.start_wheel)
        self.canvas.bind("<Leave>", self.stop_wheel)

    def update_scroll_region(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def update_width(self, event):
        self.canvas.itemconfigure(self.window_id, width=event.width)

    def start_wheel(self, event):
        self.canvas.bind_all("<MouseWheel>", self.on_wheel)

    def stop_wheel(self, event):
        self.canvas.unbind_all("<MouseWheel>")

    def on_wheel(self, event):
        if self.inner.winfo_height() > self.canvas.winfo_height():
            self.canvas.yview_scroll(-event.delta // 120, "units")

    def scroll_to_top(self):
        self.canvas.yview_moveto(0)

    def scroll_to_bottom(self):
        self.update_idletasks()
        self.canvas.yview_moveto(1)
