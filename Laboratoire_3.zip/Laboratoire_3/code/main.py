import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Controlleur import AppController  # noqa: E402
from Gestion.systeme_tickets import TicketSystem  
from Vue import TicketApp  


def main():
    TicketApp(AppController(TicketSystem())).run()


if __name__ == "__main__":
    main()
